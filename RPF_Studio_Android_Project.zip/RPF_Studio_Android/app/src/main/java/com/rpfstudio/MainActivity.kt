package com.rpfstudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.Color
import android.view.ViewGroup
import android.text.TextUtils

/**
 * RPF Studio prototype UI.
 * SAF file selection works. RPF parsing/writing must be connected to the Rust
 * rpf-archive engine before archive operations can be enabled.
 */
class MainActivity : Activity() {
    private val pickRpf = 1001
    private val pickReplacement = 1002
    private var archiveUri: Uri? = null
    private var selectedEntry: String? = null
    private lateinit var status: TextView
    private lateinit var archiveName: TextView
    private lateinit var fileList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 24, 32)
        window.navigationBarColor = Color.rgb(20, 24, 32)
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 250))
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        val header = TextView(this).apply {
            text = "RPF STUDIO"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(18), dp(16), dp(18))
            setBackgroundColor(Color.rgb(20, 24, 32))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        archiveName = TextView(this).apply {
            text = "No archive selected"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(30, 35, 45))
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(archiveName)
        root.addView(actionButton("OPEN RPF FILE") { openArchive() })
        status = TextView(this).apply {
            text = "Choose update2.rpf to begin."
            textSize = 13f
            setTextColor(Color.rgb(80, 88, 100))
            setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(status)
        val section = TextView(this).apply {
            text = "ARCHIVE CONTENTS"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(90, 98, 110))
            setPadding(0, dp(10), 0, dp(8))
        }
        root.addView(section)
        val scroll = ScrollView(this)
        fileList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(fileList)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(actionButton("EXTRACT") {
            showInfo("Extraction becomes available after the RPF engine is connected.")
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(actionButton("REPLACE") {
            if (selectedEntry == null) showInfo("Select a file entry first.")
            else {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(i, pickReplacement)
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(actionButton("SAVE AS") {
            showInfo("Saving a rebuilt RPF requires the RPF writer engine; it is not active in this prototype.")
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(actions)
        setContentView(root)
        showPrototypeEntries()
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun openArchive() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, pickRpf)
    }

    private fun showPrototypeEntries() {
        fileList.removeAllViews()
        val note = TextView(this).apply {
            text = "RPF entries will appear here after the archive engine is integrated. This prototype does not pretend to parse RPF files yet."
            textSize = 14f
            setTextColor(Color.rgb(95, 102, 112))
            setPadding(dp(12), dp(16), dp(12), dp(16))
        }
        fileList.addView(note)
    }

    private fun showInfo(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        status.text = message
    }

    @Deprecated("Deprecated in Android SDK; retained for broad compatibility in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            pickRpf -> {
                archiveUri = uri
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                archiveName.text = uri.lastPathSegment ?: "Selected archive"
                status.text = "Archive selected. RPF parser is not connected yet."
                showInfo("File selected. This starter project still needs the RPF engine.")
            }
            pickReplacement -> {
                showInfo("Replacement file selected, but writing it into the RPF is not enabled yet.")
            }
        }
    }
}
